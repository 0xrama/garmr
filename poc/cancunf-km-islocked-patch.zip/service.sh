#!/system/bin/sh
# Replace the KM trustlet with the patched version via bind mount
TRUSTLET=/vendor/app/mcRegistry/0706000000000000000000000000004d.tlbin
MODDIR=${0%/*}

if [ ! -f "$MODDIR/0706000000000000000000000000004d.tlbin" ]; then
    echo "KM patch: trustlet binary missing"
    exit 1
fi

# bind mount the patched trustlet over the stock one
mount --bind "$MODDIR/0706000000000000000000000000004d.tlbin" "$TRUSTLET"
if [ $? -eq 0 ]; then
    echo "KM patch: bind mount successful"
else
    echo "KM patch: bind mount failed, trying copy"
    # fallback: copy if possible (may fail on EROFS)
    cp "$MODDIR/0706000000000000000000000000004d.tlbin" "$TRUSTLET" 2>/dev/null
fi
