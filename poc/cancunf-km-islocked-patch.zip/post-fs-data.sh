#!/system/bin/sh
# post-fs-data: runs earlier than service.sh, before most services start
TRUSTLET=/vendor/app/mcRegistry/0706000000000000000000000000004d.tlbin
MODDIR=${0%/*}

if [ ! -f "$MODDIR/0706000000000000000000000000004d.tlbin" ]; then
    echo "KM patch: trustlet binary missing from $MODDIR"
    exit 1
fi

mount --bind "$MODDIR/0706000000000000000000000000004d.tlbin" "$TRUSTLET" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "KM patch: post-fs-data bind mount OK"
else
    echo "KM patch: bind mount FAILED, try later"
fi

# delayed restart of keymint service so it picks up the patched trustlet
(sleep 5; setprop ctl.restart vendor.keymaster_attestation-1-1 2>/dev/null; setprop ctl.restart keymint-1-1 2>/dev/null) &
